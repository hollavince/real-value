//initialize map //
L.mapbox.accessToken = 'pk.eyJ1IjoidmluY2VudGppYW5nNzc3IiwiYSI6IkNUeUV4LWMifQ.OuNUoSfqSTSyu4R-dffXKQ';
var map = L.mapbox.map('map', 'mapbox.light')
	.setView([42.3401, -71.0000], 13);
